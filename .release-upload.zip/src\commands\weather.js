const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const { WeatherError, getCurrentWeather } = require('../services/weatherService');
const { getGuildConfig } = require('../utils/guildConfig');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('weather')
    .setDescription('查詢目前天氣')
    .addStringOption((option) =>
      option
        .setName('city')
        .setDescription('城市名稱，例如 Taipei、Tokyo、New York')
        .setMaxLength(100)
    ),

  async execute(interaction) {
    const inputCity = interaction.options.getString('city');
    const defaultCity = interaction.inGuild() ? getGuildConfig(interaction.guildId).weatherDefaultCity : null;
    const city = inputCity || defaultCity;

    if (!city) {
      await interaction.reply({
        content: '請輸入城市，例如 `/weather city:Taipei`，或請管理員用 `/config weather-default-city` 設定預設城市。',
        ephemeral: true,
      });
      return;
    }

    await interaction.deferReply();

    try {
      const weather = await getCurrentWeather(city);
      const embed = new EmbedBuilder()
        .setColor(0x38bdf8)
        .setTitle(`天氣：${weather.city}`)
        .setDescription(weather.description)
        .addFields(
          { name: '溫度', value: weather.temperature, inline: true },
          { name: '體感', value: weather.feelsLike, inline: true },
          { name: '濕度', value: weather.humidity, inline: true },
          { name: '風速', value: weather.windSpeed, inline: true }
        )
        .setTimestamp(new Date());

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      const message = error instanceof WeatherError ? error.message : '查詢天氣失敗，請稍後再試。';
      await interaction.editReply(message);
    }
  },
};
