const OPENWEATHER_URL = 'https://api.openweathermap.org/data/2.5/weather';

class WeatherError extends Error {
  constructor(message, code) {
    super(message);
    this.name = 'WeatherError';
    this.code = code;
  }
}

function requireWeatherApiKey() {
  const apiKey = process.env.OPENWEATHER_API_KEY;

  if (!apiKey) {
    throw new WeatherError('尚未設定 OPENWEATHER_API_KEY。', 'missing_api_key');
  }

  return apiKey;
}

function formatTemperature(value) {
  return `${Math.round(value * 10) / 10}°C`;
}

async function getCurrentWeather(city) {
  const apiKey = requireWeatherApiKey();
  const normalizedCity = String(city || '').trim();

  if (!normalizedCity) {
    throw new WeatherError('請輸入城市名稱。', 'missing_city');
  }

  const url = new URL(OPENWEATHER_URL);
  url.searchParams.set('q', normalizedCity);
  url.searchParams.set('appid', apiKey);
  url.searchParams.set('units', 'metric');
  url.searchParams.set('lang', 'zh_tw');

  const response = await fetch(url);

  if (response.status === 401) {
    throw new WeatherError(
      'OpenWeather API key 無效或尚未啟用。請確認 .env 的 OPENWEATHER_API_KEY 是有效 key，儲存後重新啟動小吉；新 key 有時需要等待幾分鐘才會生效。',
      'unauthorized'
    );
  }

  if (response.status === 404) {
    throw new WeatherError(`找不到城市：${normalizedCity}`, 'city_not_found');
  }

  if (!response.ok) {
    throw new WeatherError(`OpenWeather 回應錯誤：HTTP ${response.status}`, 'provider_error');
  }

  const data = await response.json();
  const weather = data.weather?.[0];

  return {
    city: `${data.name}${data.sys?.country ? `, ${data.sys.country}` : ''}`,
    description: weather?.description || '未知',
    temperature: formatTemperature(data.main.temp),
    feelsLike: formatTemperature(data.main.feels_like),
    humidity: `${data.main.humidity}%`,
    windSpeed: `${data.wind?.speed ?? 0} m/s`,
  };
}

module.exports = {
  WeatherError,
  getCurrentWeather,
};
