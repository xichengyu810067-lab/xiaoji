const { generateChatReply } = require('./aiService');
const { WeatherError, getCurrentWeather } = require('./weatherService');
const logger = require('../utils/logger');

const weatherKeywords = ['天氣', '氣溫', '溫度', 'weather'];

function createBotMentionPattern(botId) {
  return new RegExp(`<@!?${botId}>`, 'g');
}

function getMentionText(content, botId) {
  const mentionPattern = createBotMentionPattern(botId);

  if (!mentionPattern.test(content)) {
    return null;
  }

  return content.replace(createBotMentionPattern(botId), '').trim();
}

function isWeatherRequest(userText) {
  const normalized = String(userText || '').toLowerCase();
  return weatherKeywords.some((keyword) => normalized.includes(keyword));
}

function isWeatherCapabilityQuestion(userText) {
  return /功能|支援|有沒有|會不會|能不能/.test(String(userText || ''));
}

function extractWeatherCity(userText) {
  const cleaned = String(userText || '')
    .replace(/請問|請幫我|幫我|查詢|查一下|查|看看|現在|目前|可以|能不能|能|嗎|呢|功能|的|天氣|氣溫|溫度|weather|[?？!！。]/gi, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  return cleaned || null;
}

function formatWeatherReply(weather) {
  return [
    `可以，${weather.city} 目前天氣是 ${weather.description}。`,
    `溫度 ${weather.temperature}，體感 ${weather.feelsLike}，濕度 ${weather.humidity}，風速 ${weather.windSpeed}。`,
  ].join('\n');
}

async function getWeatherMentionReply(userText) {
  if (!isWeatherRequest(userText)) {
    return null;
  }

  if (isWeatherCapabilityQuestion(userText)) {
    return '小吉有查詢天氣功能。請使用 `/weather city:Taipei`，或直接問我「查 Taipei 天氣」。';
  }

  const city = extractWeatherCity(userText);

  if (!city) {
    return '小吉有查詢天氣功能。請使用 `/weather city:Taipei`，或直接問我「查 Taipei 天氣」。';
  }

  try {
    const weather = await getCurrentWeather(city);
    return formatWeatherReply(weather);
  } catch (error) {
    if (error instanceof WeatherError && error.code === 'missing_api_key') {
      return '小吉有查詢天氣功能，但目前還沒設定 `OPENWEATHER_API_KEY`。請在 `.env` 補上後重新啟動小吉。';
    }

    if (error instanceof WeatherError && error.code === 'unauthorized') {
      return '小吉有查詢天氣功能，但 OpenWeather API key 目前無效或尚未啟用。請確認 `.env` 的 `OPENWEATHER_API_KEY` 是正確 key，儲存後重新啟動小吉。';
    }

    if (error instanceof WeatherError) {
      return `${error.message} 也可以改用 slash command：/weather city:${city}`;
    }

    logger.warn(`weather mention failed: ${error?.message || error}`);
    return `小吉有查詢天氣功能，但這次查詢失敗。你也可以試試 /weather city:${city}`;
  }
}

function getMentionFallbackReply(userText) {
  logger.info('[HELP_FALLBACK] using mention fallback reply');
  if (!userText) {
    return '小吉在，想問什麼都可以直接說。';
  }

  const normalized = userText.toLowerCase();

  if (isWeatherRequest(userText)) {
    return '小吉有查詢天氣功能。請使用 `/weather city:Taipei`，或直接問我「查 Taipei 天氣」。';
  }

  if (userText.includes('早安') || userText.includes('你好') || normalized.includes('hi')) {
    return '你好，我是小吉。需要指令說明可以輸入 /help。';
  }

  if (userText.includes('幫助') || userText.includes('指令')) {
    return '你可以輸入 /help 查看小吉目前支援的指令，也可以使用 /weather 查詢天氣。';
  }

  return `我收到你的訊息：「${userText}」。`;
}

function splitReply(content, maxLength = 1800) {
  if (content.length <= maxLength) {
    return [content];
  }

  const chunks = [];
  let remaining = content;

  while (remaining.length > maxLength) {
    let splitAt = remaining.lastIndexOf('\n', maxLength);

    if (splitAt < Math.floor(maxLength * 0.6)) {
      splitAt = remaining.lastIndexOf('。', maxLength);
      if (splitAt >= Math.floor(maxLength * 0.6)) {
        splitAt += 1;
      }
    }

    if (splitAt < Math.floor(maxLength * 0.6)) {
      splitAt = maxLength;
    }

    chunks.push(remaining.slice(0, splitAt).trim());
    remaining = remaining.slice(splitAt).trim();
  }

  if (remaining) {
    chunks.push(remaining);
  }

  return chunks;
}

async function replyInChunks(message, content) {
  const [firstChunk, ...restChunks] = splitReply(content);

  await message.reply({
    content: firstChunk,
    allowedMentions: { repliedUser: false },
  });

  for (const chunk of restChunks) {
    await message.channel.send({ content: chunk, allowedMentions: { parse: [] } });
  }
}

async function handleMentionMessage(message) {
  const botId = message.client.user?.id;

  if (!botId) {
    return;
  }

  const userText = getMentionText(message.content, botId);

  if (userText === null) {
    return;
  }

  logger.info(`[mention] ${message.author.tag}: ${message.content}`);

  const weatherReply = await getWeatherMentionReply(userText);

  if (weatherReply) {
    await replyInChunks(message, weatherReply);
    return;
  }

  let reply;

  try {
    reply = await generateChatReply({
      userText,
      username: message.author.username,
      channelId: message.channelId,
      guildId: message.guildId,
    });
  } catch (error) {
    logger.error('AI mention reply failed', error);
  }

  await replyInChunks(message, reply || getMentionFallbackReply(userText));
}

module.exports = {
  extractWeatherCity,
  getMentionFallbackReply,
  getMentionText,
  getWeatherMentionReply,
  handleMentionMessage,
  isWeatherCapabilityQuestion,
  isWeatherRequest,
  splitReply,
};
