const test = require('node:test');
const assert = require('node:assert/strict');
const {
  extractWeatherCity,
  getMentionFallbackReply,
  isWeatherCapabilityQuestion,
  isWeatherRequest,
} = require('../src/services/mentionService');
const { developerInstructions } = require('../src/services/aiService');

test('AI instructions know Xiaoji has weather command', () => {
  assert.match(developerInstructions, /\/weather/);
  assert.match(developerInstructions, /Never say Xiaoji has no weather feature/);
});

test('mention fallback advertises weather support', () => {
  assert.match(getMentionFallbackReply('你有查詢天氣功能嗎'), /\/weather/);
});

test('weather request detection recognizes Chinese and English', () => {
  assert.equal(isWeatherRequest('查台北天氣'), true);
  assert.equal(isWeatherRequest('weather Taipei'), true);
});

test('weather capability question is not treated as a city lookup', () => {
  assert.equal(isWeatherCapabilityQuestion('你有沒有查詢天氣功能嗎'), true);
});

test('extractWeatherCity extracts city from a simple weather request', () => {
  assert.equal(extractWeatherCity('查 Taipei 天氣'), 'Taipei');
});
